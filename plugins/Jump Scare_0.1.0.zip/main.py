def on_start():
    disable_tts()


def on_command(command, name, guest):
    if command == "wilhelm":
        play_sound("sounds/wilhelm.wav")

    if command == "chonky_cat_claxoning":
        play_sound("sounds/chonky_cat_claxoning.wav")
